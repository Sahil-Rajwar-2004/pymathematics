author = "Sahil Rajwar"
version = "2023.5.3.1"
homepage = "https://github.com/Sahil-Rajwar-2004/pymathematics"