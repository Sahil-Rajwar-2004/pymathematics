# pymathematics v-2023.4.24

* linux/macOS: `pip3 install pymathematics`
* for windows: `pip install pymathematics`
 
