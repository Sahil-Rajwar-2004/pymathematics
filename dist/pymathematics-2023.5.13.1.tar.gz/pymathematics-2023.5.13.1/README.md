# pymathematics v-2023.5.13.1

# Requirements
* sympy

# Installation
* linux/macOS: `pip3 install pymathematics`
* for windows: `pip install pymathematics`
 
