# pymathematics v-2023.4.25.1

# Requirements
* sympy

* linux/macOS: `pip3 install pymathematics`
* for windows: `pip install pymathematics`
 
