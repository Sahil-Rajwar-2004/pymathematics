# pymathematics v-2023.4.21

* linux/macOS: `pip3 install pymathematics`
* for windows: `pip install pymathematics`
 
