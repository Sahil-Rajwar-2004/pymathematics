# pymathematics v-2023.4.29

# Requirements
* sympy

# Installation
* linux/macOS: `pip3 install pymathematics`
* for windows: `pip install pymathematics`
 
