author = "Sahil Rajwar"
version = "2023.4.23.1"
homepage = "https://github.com/Sahil-Rajwar-2004/pymathematics"